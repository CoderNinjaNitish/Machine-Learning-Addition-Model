from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np

app = Flask(__name__)

# Load the saved model
model = joblib.load('model_joblib')

@app.route('/')
def home():  # Renamed from index to home
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from form input
        number1 = float(request.form['number1'])
        number2 = float(request.form['number2'])
        
        # Prepare the data for prediction
        input_data = np.array([[number1, number2]])

        # Predict using the loaded model
        prediction = model.predict(input_data)

        # Return the prediction result as JSON
        return jsonify({'prediction': prediction[0]})
    except Exception as e:
        return str(e)

if __name__ == '__main__':
    app.run(debug=True)
